import React from 'react';
import { WeatherData } from '../types/weather';
import {
  Sun,
  CloudSun,
  Cloud,
  CloudRain,
  CloudLightning,
  CloudFog,
  Wind,
  Droplets,
  Sunrise,
  Sunset,
  ArrowUp,
  ArrowDown,
  Clock,
  Compass,
  AlertCircle,
} from 'lucide-react';

interface CurrentWeatherProps {
  data: WeatherData;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export const CurrentWeather: React.FC<CurrentWeatherProps> = ({
  data,
  onRefresh,
  isLoading = false,
}) => {
  const { current, daily, location, lastUpdated, isStale } = data;
  const today = daily[0];

  const getWeatherIcon = (code: number, isDay: boolean) => {
    if (code === 0) return <Sun className="w-16 h-16 text-amber-500 drop-shadow-[0_0_18px_rgba(251,191,36,0.3)]" />;
    if (code <= 2) return <CloudSun className="w-16 h-16 text-[#00AFCB] dark:text-cyan-300 drop-shadow-[0_0_18px_rgba(0,175,203,0.3)]" />;
    if (code === 3) return <Cloud className="w-16 h-16 text-slate-600 dark:text-slate-300 drop-shadow-[0_0_18px_rgba(100,116,139,0.3)]" />;
    if (code >= 51 && code <= 82) return <CloudRain className="w-16 h-16 text-[#2563EB] dark:text-blue-400 drop-shadow-[0_0_18px_rgba(37,99,235,0.3)]" />;
    if (code >= 95) return <CloudLightning className="w-16 h-16 text-amber-600 dark:text-amber-400 drop-shadow-[0_0_22px_rgba(217,119,6,0.4)]" />;
    return <CloudFog className="w-16 h-16 text-slate-600 dark:text-slate-400" />;
  };

  return (
    <div className="w-full glass-panel rounded-2xl p-5 md:p-7 relative overflow-hidden transition-all">
      {/* Background ambient radial glow */}
      <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-cyan-500/10 dark:bg-cyan-600/10 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-blue-500/10 dark:bg-blue-600/10 blur-3xl pointer-events-none" />

      {/* Top Banner: Location Name and clean state tag */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#D8E4ED] dark:border-cyan-500/15">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="font-display text-2xl md:text-3xl font-bold text-[#172B3A] dark:text-white tracking-tight">
              {location.name}
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[#172B3A] dark:text-slate-200 text-xs font-semibold border border-[#D8E4ED] dark:border-slate-700 shadow-sm">
              {location.state}, {location.country}
            </span>
          </div>
          <div className="flex items-center gap-2 mt-1 text-xs text-[#526779] dark:text-slate-400 font-normal">
            <span className="flex items-center gap-1 font-mono">
              <Compass className="w-3.5 h-3.5 text-[#00AFCB] dark:text-cyan-400" />
              {location.latitude.toFixed(4)}°N, {location.longitude.toFixed(4)}°E
            </span>
            <span>•</span>
            <span>Elevation: ~{location.elevation ?? 650} m</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-xs font-bold border border-emerald-300 dark:border-emerald-500/30 shadow-sm">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span>LIVE</span>
          </span>

          {isStale && (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-100 dark:bg-amber-500/20 text-amber-900 dark:text-amber-300 text-xs font-semibold border border-amber-300 dark:border-amber-500/30">
              <AlertCircle className="w-3.5 h-3.5" />
              Cached Telemetry
            </span>
          )}

          <div className="flex items-center gap-1.5 text-xs text-[#526779] dark:text-slate-400 bg-[#F4F8FC] dark:bg-slate-900/60 px-3 py-1.5 rounded-xl border border-[#D8E4ED] dark:border-slate-800">
            <Clock className="w-3.5 h-3.5 text-[#00AFCB] dark:text-cyan-400" />
            <span>Updated: <strong className="text-[#172B3A] dark:text-slate-200 font-bold">{lastUpdated}</strong></span>
          </div>
        </div>
      </div>

      {/* Main Weather Information Display */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Left: Temperature & Conditions */}
        <div className="md:col-span-7 flex flex-col sm:flex-row items-start sm:items-center gap-5">
          <div className="flex-shrink-0 animate-bounce-subtle">
            {getWeatherIcon(current.weatherCode, current.isDay)}
          </div>

          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display text-5xl md:text-6xl font-extrabold text-[#172B3A] dark:text-white tracking-tighter">
                {current.temperature}°
              </span>
              <span className="font-display text-2xl font-bold text-[#526779] dark:text-slate-400">C</span>
              <span className="text-sm text-[#526779] dark:text-slate-300 ml-2 font-normal">
                Feels like <strong className="text-[#007A8E] dark:text-cyan-300 font-bold">{current.apparentTemperature}°C</strong>
              </span>
            </div>

            <p className="font-body text-base md:text-lg font-bold text-[#007A8E] dark:text-cyan-200 mt-1 capitalize">
              {current.weatherDescription}
            </p>

            {today && (
              <div className="flex items-center gap-4 mt-2 text-xs font-normal text-[#526779] dark:text-slate-300">
                <span className="flex items-center gap-1 text-rose-700 dark:text-rose-400 font-semibold">
                  <ArrowUp className="w-3.5 h-3.5" />
                  High: <strong className="font-mono text-[#172B3A] dark:text-white font-bold">{today.tempMax}°C</strong>
                </span>
                <span className="flex items-center gap-1 text-[#2563EB] dark:text-cyan-400 font-semibold">
                  <ArrowDown className="w-3.5 h-3.5" />
                  Low: <strong className="font-mono text-[#172B3A] dark:text-white font-bold">{today.tempMin}°C</strong>
                </span>
                <span className="text-[#526779] dark:text-slate-400">
                  Rain Prob: <strong className="text-[#007A8E] dark:text-cyan-300 font-bold">{today.precipitationProbabilityMax}%</strong>
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Right: Sun Cycle & Atmospheric Summary */}
        <div className="md:col-span-5 grid grid-cols-2 gap-3 pt-3 md:pt-0 md:border-l md:border-[#D8E4ED] dark:md:border-cyan-500/15 md:pl-6">
          {/* Sunrise */}
          <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-slate-900/50 border border-[#D8E4ED] dark:border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-100/90 text-amber-800 dark:bg-amber-500/15 dark:text-amber-400">
              <Sunrise className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-[#526779] dark:text-slate-400 uppercase tracking-wider block font-bold">Sunrise</span>
              <span className="text-xs font-bold text-[#172B3A] dark:text-white font-mono">{today?.sunrise ?? '06:08 AM'}</span>
            </div>
          </div>

          {/* Sunset */}
          <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-slate-900/50 border border-[#D8E4ED] dark:border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-orange-100/90 text-orange-800 dark:bg-orange-500/15 dark:text-orange-400">
              <Sunset className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-[#526779] dark:text-slate-400 uppercase tracking-wider block font-bold">Sunset</span>
              <span className="text-xs font-bold text-[#172B3A] dark:text-white font-mono">{today?.sunset ?? '06:18 PM'}</span>
            </div>
          </div>

          {/* Cloud Cover */}
          <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-slate-900/50 border border-[#D8E4ED] dark:border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-100/90 text-[#007A8E] dark:bg-cyan-500/15 dark:text-cyan-400">
              <Cloud className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-[#526779] dark:text-slate-400 uppercase tracking-wider block font-bold">Cloud Cover</span>
              <span className="text-xs font-bold text-[#172B3A] dark:text-white font-mono">{current.cloudCover}%</span>
            </div>
          </div>

          {/* Surface Pressure */}
          <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-slate-900/50 border border-[#D8E4ED] dark:border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-100/90 text-[#2563EB] dark:bg-blue-500/15 dark:text-blue-400">
              <Wind className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-[#526779] dark:text-slate-400 uppercase tracking-wider block font-bold">Barometer</span>
              <span className="text-xs font-bold text-[#172B3A] dark:text-white font-mono">{current.surfacePressure} hPa</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
