import React, { useState } from 'react';
import { X, Moon, Sun, Settings, Compass, Shield, Download, Check, Copy, Share2, Globe } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  theme,
  setTheme,
}) => {
  const { isInstallable, isInstalled, install, markAsDownloaded } = usePWAInstall();
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const publicWebUrl = window.location.origin;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicWebUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in"
    >
      <div className="w-full max-w-md max-h-[90dvh] overflow-y-auto rounded-2xl bg-white dark:bg-[#09152b] border border-[#D8E4ED] dark:border-cyan-500/30 p-5 sm:p-6 shadow-2xl text-[#172B3A] dark:text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#D8E4ED] dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-100 dark:bg-cyan-500/20 text-[#00AFCB] dark:text-cyan-400 border border-cyan-200 dark:border-cyan-500/30">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-[#172B3A] dark:text-white">Platform Settings & Info</h3>
              <p className="text-[11px] text-[#687D8F] dark:text-slate-400 font-normal">SkyCast India Configuration & Sharing</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-[#F4F8FC] dark:hover:bg-slate-800 text-[#687D8F] hover:text-[#172B3A] dark:hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Options */}
        <div className="mt-4 space-y-3.5 text-xs">
          {/* Appearance Theme */}
          <div className="space-y-2">
            <label className="font-bold text-[#172B3A] dark:text-slate-300 uppercase tracking-wider text-[11px] block">
              Color Interface Theme
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setTheme('dark')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-cyan-100 dark:bg-cyan-500/20 border-cyan-500/50 text-[#172B3A] dark:text-cyan-200 shadow-sm'
                    : 'bg-[#F8FAFC] dark:bg-slate-900 border-[#D8E4ED] dark:border-slate-800 text-[#526779] dark:text-slate-400 hover:text-[#172B3A] dark:hover:text-white'
                }`}
              >
                <Moon className="w-4 h-4 text-[#00AFCB] dark:text-cyan-400" />
                <span>Midnight Dark</span>
              </button>

              <button
                onClick={() => setTheme('light')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                  theme === 'light'
                    ? 'bg-[#E6F8FA] border-[#00AFCB] text-[#172B3A] dark:bg-cyan-500/20 dark:border-cyan-500/50 dark:text-cyan-200 shadow-sm'
                    : 'bg-[#F8FAFC] dark:bg-slate-900 border-[#D8E4ED] dark:border-slate-800 text-[#526779] dark:text-slate-400 hover:text-[#172B3A] dark:hover:text-white'
                }`}
              >
                <Sun className="w-4 h-4 text-amber-500" />
                <span>Clean Daylight</span>
              </button>
            </div>
          </div>

          {/* Android App Status */}
          <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-slate-900/60 border border-[#D8E4ED] dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-bold text-[#172B3A] dark:text-white">
                <svg className="w-4 h-4 fill-current text-emerald-600 dark:text-emerald-400" viewBox="0 0 24 24">
                  <path d="M17.523 15.3414c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.551 0 .9993.4482.9993.9993.0001.5511-.4483.9997-.9993.9997m-11.046 0c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9993.4482.9993.9993 0 .5511-.4482.9997-.9993.9997m11.4045-6.02l1.997-3.459a.416.416 0 00-.1521-.5676.416.416 0 00-.5676.1521l-2.0223 3.503C15.5902 8.4116 13.8533 8.1 12 8.1c-1.8533 0-3.5902.3116-5.1365.8499L4.8412 5.447a.4162.4162 0 00-.5676-.1521.4157.4157 0 00-.1521.5676l1.997 3.459C2.6889 11.1867.3432 14.6589 0 18.761h24c-.3432-4.1021-2.6889-7.5743-6.1185-9.4396" />
                </svg>
                <span>Android App Status</span>
              </div>
              {isInstalled ? (
                <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                  <Check className="w-3.5 h-3.5" />
                  App Installed & Active
                </span>
              ) : (
                <span className="text-[10px] text-amber-700 dark:text-amber-400 font-semibold">
                  Not Installed Yet
                </span>
              )}
            </div>

            {isInstalled ? (
              <p className="text-[#526779] dark:text-slate-400 text-[11px]">
                The app is saved to your device. Download prompts are suppressed automatically.
              </p>
            ) : (
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={async () => {
                    if (isInstallable) await install();
                    else markAsDownloaded();
                  }}
                  className="flex-1 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download App on Android</span>
                </button>
              </div>
            )}
          </div>

          {/* Public Web URL & Share */}
          <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-slate-900/60 border border-[#D8E4ED] dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-bold text-[#172B3A] dark:text-white">
                <Globe className="w-4 h-4 text-[#00AFCB] dark:text-cyan-400" />
                <span>Public Web Address</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold border border-emerald-300 dark:border-emerald-500/40">
                Live in Public
              </span>
            </div>
            <p className="text-[#526779] dark:text-slate-400 text-[11px]">
              Accessible publicly to anyone worldwide without registration or passwords.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                readOnly
                value={publicWebUrl}
                className="flex-1 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-950 border border-[#D8E4ED] dark:border-slate-800 text-[11px] text-[#172B3A] dark:text-slate-300 font-mono select-all focus:outline-none"
              />
              <button
                onClick={handleCopyLink}
                className="px-3 py-1.5 rounded-lg bg-[#00AFCB] hover:bg-cyan-600 text-white font-bold text-[11px] flex items-center gap-1 transition cursor-pointer shadow-sm"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Privacy & Zero-Login Policy */}
          <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-slate-900/60 border border-[#D8E4ED] dark:border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-emerald-800 dark:text-emerald-400">
              <Shield className="w-3.5 h-3.5" />
              <span>Zero-Login Guarantee</span>
            </div>
            <p className="text-[#526779] dark:text-slate-400 text-[11px]">
              User preferences and cached frames reside entirely in your browser's local sandbox.
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full rounded-xl bg-[#00AFCB] hover:bg-cyan-600 py-2.5 text-xs font-bold text-white transition cursor-pointer shadow-md"
        >
          Close
        </button>
      </div>
    </div>
  );
};

