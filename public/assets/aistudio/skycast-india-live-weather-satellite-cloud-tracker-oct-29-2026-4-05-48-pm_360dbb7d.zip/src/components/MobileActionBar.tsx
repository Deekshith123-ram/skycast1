import React from 'react';
import { Moon, Sun, RefreshCw, Settings } from 'lucide-react';

interface MobileActionBarProps {
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  onRefresh: () => void;
  isLoading: boolean;
  onOpenSettings: () => void;
}

// Phone-only bottom toolbar: keeps Theme, Refresh and Settings always visible and thumb-reachable
export const MobileActionBar: React.FC<MobileActionBarProps> = ({
  theme,
  setTheme,
  onRefresh,
  isLoading,
  onOpenSettings,
}) => {
  const itemClass =
    'flex-1 flex flex-col items-center justify-center gap-0.5 py-2 rounded-xl text-[11px] font-semibold text-[#172B3A] dark:text-slate-300 hover:text-[#00AFCB] active:scale-95 active:bg-[#F4F8FC] dark:active:bg-slate-800 transition cursor-pointer';

  return (
    <nav
      className="sm:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-[#050b18]/95 backdrop-blur-xl border-t border-[#D8E4ED] dark:border-cyan-500/15 shadow-[0_-4px_20px_rgba(23,43,58,0.08)] pb-[env(safe-area-inset-bottom)]"
      aria-label="App options"
    >
      <div className="flex items-stretch gap-1 px-2 py-1">
        {/* Segmented Dark / Light switch */}
        <div className="flex-[2] flex items-center p-1 my-1 rounded-xl bg-[#F4F8FC] dark:bg-slate-900/80 border border-[#D8E4ED] dark:border-slate-800">
          <button
            onClick={() => setTheme('dark')}
            aria-pressed={theme === 'dark'}
            className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-bold transition cursor-pointer ${
              theme === 'dark'
                ? 'bg-cyan-500/20 text-cyan-300 shadow-sm'
                : 'text-[#526779] dark:text-slate-500'
            }`}
          >
            <Moon className="w-3.5 h-3.5" />
            <span>Dark</span>
          </button>
          <button
            onClick={() => setTheme('light')}
            aria-pressed={theme === 'light'}
            className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-bold transition cursor-pointer ${
              theme === 'light'
                ? 'bg-white text-amber-700 shadow-sm border border-[#D8E4ED]'
                : 'text-[#526779] dark:text-slate-400'
            }`}
          >
            <Sun className="w-3.5 h-3.5" />
            <span>Light</span>
          </button>
        </div>

        <button onClick={onRefresh} disabled={isLoading} className={itemClass}>
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-[#00AFCB] dark:text-cyan-400' : ''}`} />
          <span>Refresh</span>
        </button>

        <button onClick={onOpenSettings} className={itemClass}>
          <Settings className="w-4 h-4" />
          <span>Settings</span>
        </button>
      </div>
    </nav>
  );
};
