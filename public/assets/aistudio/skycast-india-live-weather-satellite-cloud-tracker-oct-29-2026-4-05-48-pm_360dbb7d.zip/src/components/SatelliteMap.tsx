import React, { useEffect, useRef, useState, useCallback } from 'react';
import L from 'leaflet';
import {
  LocationData,
  WeatherData,
  DistrictRainData,
} from '../types/weather';
import {
  getNasaGibsTileUrl,
  getGibsDateString,
  fetchSatelliteRadarFrames,
} from '../services/satelliteService';
import { fetchAllKarnatakaDistrictsRain } from '../services/weatherService';
import {
  Maximize2,
  Minimize2,
  Layers,
  MapPin,
  Clock,
  Compass,
  Radio,
  Wind,
  CloudRain,
  Sun,
  Cloud,
  Droplets,
  Plus,
  Minus,
  Sparkles,
  X,
  Check,
} from 'lucide-react';

interface SatelliteMapProps {
  currentLocation: LocationData;
  weatherData?: WeatherData | null;
  onSelectLocation?: (loc: LocationData) => void;
  theme?: 'dark' | 'light';
  className?: string;
}

export type ActiveLayer =
  | 'satellite_gibs_terra'
  | 'satellite_gibs_viirs'
  | 'radar_rainviewer'
  | 'cloud_cover'
  | 'wind_flow'
  | 'temperature';

export const SatelliteMap: React.FC<SatelliteMapProps> = ({
  currentLocation,
  weatherData,
  onSelectLocation,
  theme = 'dark',
  className = '',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const baseTileLayerRef = useRef<L.TileLayer | null>(null);
  const activeTileLayerRef = useRef<L.TileLayer | null>(null);
  const locationMarkerRef = useRef<L.Marker | null>(null);
  const districtMarkersLayerRef = useRef<L.LayerGroup | null>(null);
  const windCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const [layerOpacity, setLayerOpacity] = useState<number>(0.85);
  const [activeLayer, setActiveLayer] = useState<ActiveLayer>('satellite_gibs_terra');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showLayerMenu, setShowLayerMenu] = useState<boolean>(false);
  const [showLegend, setShowLegend] = useState<boolean>(true);
  const [showDistrictRainPins, setShowDistrictRainPins] = useState<boolean>(true);
  const [districtsRainData, setDistrictsRainData] = useState<DistrictRainData[]>([]);
  const [latestRadarPath, setLatestRadarPath] = useState<string>('');
  const [tileHost, setTileHost] = useState<string>('https://tilecache.rainviewer.com');
  const [lastRefreshedTime, setLastRefreshedTime] = useState<string>('Live');

  // Load latest radar frame metadata
  const loadRadarMetadata = useCallback(async () => {
    try {
      const data = await fetchSatelliteRadarFrames();
      setTileHost(data.host);
      // Specifically prioritize genuine radar observation paths
      const radarFrames = data.frames.filter((f) => f.path && f.path.startsWith('/v2/radar/'));
      if (radarFrames.length > 0) {
        const latest = radarFrames[radarFrames.length - 1];
        setLatestRadarPath(latest.path);
        setLastRefreshedTime(latest.formattedTime);
      } else if (data.frames.length > 0) {
        const latest = data.frames[data.frames.length - 1];
        setLatestRadarPath(latest.path);
        setLastRefreshedTime(latest.formattedTime);
      }
    } catch (err) {
      console.warn('Radar metadata fallback:', err);
    }
  }, []);

  // Load rain probability telemetry for all 31 Karnataka districts
  const loadKarnatakaDistricts = useCallback(async () => {
    try {
      const data = await fetchAllKarnatakaDistrictsRain();
      setDistrictsRainData(data);
    } catch (err) {
      console.error('Error fetching Karnataka district rain telemetry:', err);
    }
  }, []);

  useEffect(() => {
    loadRadarMetadata();
    loadKarnatakaDistricts();
    const interval = setInterval(() => {
      loadRadarMetadata();
      loadKarnatakaDistricts();
    }, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [loadRadarMetadata, loadKarnatakaDistricts]);

  // Initialize Leaflet Map with smooth zoom settings
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    // DEFAULT: Whole State of Karnataka (14.65°N, 75.85°E, Zoom: 7.2)
    const map = L.map(mapContainerRef.current, {
      center: [14.65, 75.85],
      zoom: 7.2,
      minZoom: 4,
      maxZoom: 16,
      zoomControl: false,
      attributionControl: false,
      zoomSnap: 0.25,
      zoomDelta: 0.5,
      wheelPxPerZoomLevel: 140,
      wheelDebounceTime: 40,
      zoomAnimation: true,
      zoomAnimationThreshold: 10,
      fadeAnimation: true,
      markerZoomAnimation: true,
    });

    // Theme-based basemap
    const baseTileUrl =
      theme === 'light'
        ? 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';

    const baseLayer = L.tileLayer(baseTileUrl, {
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);
    baseTileLayerRef.current = baseLayer;

    // Layer group for Karnataka district rain probability markers
    const districtGroup = L.layerGroup().addTo(map);
    districtMarkersLayerRef.current = districtGroup;

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update basemap when theme changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !baseTileLayerRef.current) return;

    map.removeLayer(baseTileLayerRef.current);
    const newBaseTileUrl =
      theme === 'light'
        ? 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';

    const newBaseLayer = L.tileLayer(newBaseTileUrl, {
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);

    // Keep basemap at bottom
    newBaseLayer.bringToBack();
    baseTileLayerRef.current = newBaseLayer;
  }, [theme]);

  // Update map center when currentLocation changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (currentLocation.id === 'karnataka-all') {
      map.flyTo([14.65, 75.85], 7.2, {
        duration: 1.2,
        easeLinearity: 0.25,
      });
    } else {
      map.flyTo([currentLocation.latitude, currentLocation.longitude], 9.25, {
        duration: 1.2,
        easeLinearity: 0.25,
      });
    }
  }, [currentLocation]);

  // Render All 31 Karnataka Districts with DIRECT TOUCH SELECTION
  useEffect(() => {
    const map = mapInstanceRef.current;
    const group = districtMarkersLayerRef.current;
    if (!map || !group) return;

    group.clearLayers();

    if (!showDistrictRainPins || districtsRainData.length === 0) return;

    districtsRainData.forEach((district) => {
      const isSelected =
        Math.abs(district.latitude - currentLocation.latitude) < 0.05 &&
        Math.abs(district.longitude - currentLocation.longitude) < 0.05;

      const prob = district.rainProbability;
      const badgeClass =
        prob >= 60
          ? 'bg-blue-600 text-white border-blue-300 ring-2 ring-blue-500/50 shadow-blue-900/60'
          : prob >= 30
          ? 'bg-cyan-600 text-white border-cyan-300 ring-1 ring-cyan-400/50 shadow-cyan-900/60'
          : theme === 'light'
          ? 'bg-white text-[#172B3A] border-[#D8E4ED] shadow-md font-bold'
          : 'bg-[#0f1f3d] text-cyan-200 border-cyan-500/40 shadow-black/80';

      const iconHtml = `
        <div class="relative cursor-pointer group flex flex-col items-center -translate-x-1/2 -translate-y-1/2 touch-manipulation select-none active:scale-95 transition-transform" style="pointer-events: auto;">
          ${isSelected ? '<span class="absolute -top-1 w-9 h-9 rounded-full bg-cyan-400/50 animate-ping-slow"></span>' : ''}
          <div class="flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold font-mono shadow-xl border backdrop-blur-md ${badgeClass}">
            <span class="text-xs">${prob >= 50 ? '🌧️' : prob >= 20 ? '🌦️' : '🌤️'}</span>
            <span>${prob}%</span>
          </div>
          <span class="mt-0.5 px-1.5 py-0.2 rounded text-[10px] tracking-tight whitespace-nowrap shadow-md ${
            theme === 'light'
              ? 'bg-white/95 text-[#172B3A] font-bold border border-[#D8E4ED]'
              : 'bg-black/90 text-white font-semibold border border-cyan-500/30'
          }">
            ${district.district}
          </span>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'karnataka-district-rain-pin',
        html: iconHtml,
        iconSize: [0, 0],
      });

      const marker = L.marker([district.latitude, district.longitude], {
        icon: customIcon,
        riseOnHover: true,
        zIndexOffset: isSelected ? 1000 : 500,
      });

      // DIRECT TOUCH / CLICK SELECTION: Instantly selects district on tap
      marker.on('click', () => {
        if (onSelectLocation) {
          onSelectLocation({
            id: district.id,
            name: district.name,
            district: district.district,
            state: 'Karnataka',
            country: 'India',
            latitude: district.latitude,
            longitude: district.longitude,
          });
        }
      });

      // Informative popup
      marker.bindPopup(`
        <div class="text-xs p-1.5 min-w-[210px] ${theme === 'light' ? 'bg-white text-slate-900' : 'bg-[#09152b] text-slate-100'} rounded-lg">
          <div class="flex items-center justify-between pb-1.5 border-b ${theme === 'light' ? 'border-slate-200' : 'border-cyan-500/30'}">
            <strong class="${theme === 'light' ? 'text-cyan-700' : 'text-cyan-300'} font-bold text-sm">📍 ${district.district}</strong>
            <span class="px-1.5 py-0.2 rounded ${theme === 'light' ? 'bg-cyan-100 text-cyan-800' : 'bg-cyan-950 text-cyan-300'} font-mono text-[10px] border border-cyan-500/30">${district.region}</span>
          </div>
          <div class="mt-2 space-y-1.5 ${theme === 'light' ? 'text-slate-700' : 'text-slate-200'}">
            <div class="flex items-center justify-between">
              <span class="${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}">Rain Probability:</span>
              <strong class="${theme === 'light' ? 'text-cyan-700' : 'text-cyan-300'} font-mono text-sm">${district.rainProbability}%</strong>
            </div>
            <div class="flex items-center justify-between">
              <span class="${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}">Expected 24h Rain:</span>
              <span class="font-mono font-semibold ${theme === 'light' ? 'text-slate-900' : 'text-white'}">${district.precipitationSum} mm</span>
            </div>
            <div class="flex items-center justify-between">
              <span class="${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}">Temperature Span:</span>
              <span class="font-mono ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}">${district.tempMin}° – ${district.tempMax}°C</span>
            </div>
            <div class="flex items-center justify-between">
              <span class="${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}">Condition:</span>
              <span class="font-medium ${theme === 'light' ? 'text-slate-800' : 'text-slate-200'}">${district.weatherDescription}</span>
            </div>
          </div>
          <div class="mt-2 pt-1.5 border-t ${theme === 'light' ? 'border-slate-200 text-cyan-700' : 'border-slate-800 text-cyan-400'} text-[10px] text-center font-semibold">
            ✓ District Selected in Dashboard
          </div>
        </div>
      `);

      marker.addTo(group);
    });
  }, [districtsRainData, currentLocation, showDistrictRainPins, onSelectLocation, theme]);

  // Selected focal marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (locationMarkerRef.current) {
      map.removeLayer(locationMarkerRef.current);
      locationMarkerRef.current = null;
    }

    if (currentLocation.id === 'karnataka-all') return;

    const customIcon = L.divIcon({
      className: 'custom-location-marker',
      html: `
        <div class="relative flex items-center justify-center -translate-x-1/2 -translate-y-1/2 pointer-events-none">
          <span class="absolute w-12 h-12 rounded-full bg-cyan-400/40 animate-ping-slow"></span>
          <span class="absolute w-7 h-7 rounded-full bg-cyan-500/60"></span>
          <span class="relative w-4 h-4 rounded-full bg-cyan-200 border-2 border-white shadow-2xl shadow-cyan-400"></span>
          <div class="absolute top-6 left-1/2 -translate-x-1/2 whitespace-nowrap px-2.5 py-1 rounded-md text-[11px] font-bold shadow-2xl ${
            theme === 'light'
              ? 'bg-white text-[#172B3A] border-2 border-[#00AFCB]'
              : 'bg-[#050e1f] border border-cyan-400 text-cyan-200'
          }">
            📍 ${currentLocation.name}
          </div>
        </div>
      `,
      iconSize: [0, 0],
    });

    const marker = L.marker([currentLocation.latitude, currentLocation.longitude], {
      icon: customIcon,
      zIndexOffset: 1200,
    }).addTo(map);

    locationMarkerRef.current = marker;
  }, [currentLocation, theme]);

  // Active Tile Layer with maxNativeZoom so cloudy map stays visible at all zoom levels
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (activeTileLayerRef.current) {
      map.removeLayer(activeTileLayerRef.current);
      activeTileLayerRef.current = null;
    }

    let newTileLayer: L.TileLayer | null = null;

    if (activeLayer === 'satellite_gibs_terra') {
      const url = getNasaGibsTileUrl('MODIS_Terra', getGibsDateString(0));
      newTileLayer = L.tileLayer(url, {
        maxNativeZoom: 8,
        maxZoom: 16,
        minZoom: 1,
        opacity: layerOpacity,
        tileSize: 256,
      });
    } else if (activeLayer === 'satellite_gibs_viirs') {
      const url = getNasaGibsTileUrl('VIIRS_SNPP', getGibsDateString(0));
      newTileLayer = L.tileLayer(url, {
        maxNativeZoom: 8,
        maxZoom: 16,
        minZoom: 1,
        opacity: layerOpacity,
        tileSize: 256,
      });
    } else if (activeLayer === 'radar_rainviewer') {
      const radarPath = latestRadarPath || '/v2/radar/5a2bb9512c16';
      const url = `${tileHost}${radarPath}/256/{z}/{x}/{y}/2/1_1.png`;
      newTileLayer = L.tileLayer(url, {
        maxNativeZoom: 12,
        maxZoom: 16,
        minZoom: 2,
        opacity: layerOpacity,
        tileSize: 256,
      });
    } else if (activeLayer === 'cloud_cover') {
      // Aqua afternoon pass has 12-24h publication lag on NASA GIBS; getGibsDateString(1) gives verified cloud reflectance
      const url = getNasaGibsTileUrl('MODIS_Aqua', getGibsDateString(1));
      newTileLayer = L.tileLayer(url, {
        maxNativeZoom: 8,
        maxZoom: 16,
        minZoom: 1,
        opacity: layerOpacity,
        tileSize: 256,
      });
    } else if (activeLayer === 'wind_flow') {
      // Keep true-color NASA satellite context layer underneath dynamic wind particles
      const url = getNasaGibsTileUrl('MODIS_Terra', getGibsDateString(0));
      newTileLayer = L.tileLayer(url, {
        maxNativeZoom: 8,
        maxZoom: 16,
        minZoom: 1,
        opacity: Math.min(layerOpacity * 0.75, 0.7),
        tileSize: 256,
      });
    } else if (activeLayer === 'temperature') {
      newTileLayer = L.tileLayer(
        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        {
          maxZoom: 16,
          minZoom: 2,
          opacity: layerOpacity * 0.4,
        }
      );
    }

    if (newTileLayer) {
      newTileLayer.addTo(map);
      activeTileLayerRef.current = newTileLayer;
    }
  }, [activeLayer, latestRadarPath, tileHost, layerOpacity]);

  // Wind Particles Animation Canvas
  useEffect(() => {
    const canvas = windCanvasRef.current;
    const map = mapInstanceRef.current;
    if (!canvas || activeLayer !== 'wind_flow') {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = canvas.parentElement?.clientWidth || (map ? map.getSize().x : 800));
    let height = (canvas.height = canvas.parentElement?.clientHeight || (map ? map.getSize().y : 500));

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);
    if (map) {
      map.on('resize', handleResize);
      map.on('move', handleResize);
    }

    const particleCount = 200;
    const baseAngle = ((weatherData?.current.windDirection ?? 75) + 180) * (Math.PI / 180);
    const windSpeedFactor = Math.max(0.9, Math.min(3.0, (weatherData?.current.windSpeed ?? 10) / 6));

    const particles = Array.from({ length: particleCount }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      age: Math.floor(Math.random() * 80),
      maxAge: 45 + Math.floor(Math.random() * 50),
      speed: (1.2 + Math.random() * 2.0) * windSpeedFactor,
      angle: baseAngle + (Math.random() - 0.5) * 0.4,
    }));

    const render = () => {
      // Fade existing streaks to transparent using destination-out so the canvas NEVER turns opaque
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = 'rgba(0, 0, 0, 0.08)';
      ctx.fillRect(0, 0, width, height);

      // Draw fresh particle lines with high contrast cyan/blue styling
      ctx.globalCompositeOperation = 'source-over';

      particles.forEach((p) => {
        const vx = Math.cos(p.angle) * p.speed;
        const vy = Math.sin(p.angle) * p.speed;

        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + vx * 2.6, p.y + vy * 2.6);

        const lifeRatio = 1 - p.age / p.maxAge;
        const alpha = Math.max(0, Math.min(1, lifeRatio * 0.85));
        ctx.strokeStyle =
          theme === 'light'
            ? `rgba(2, 132, 199, ${alpha})`
            : `rgba(56, 189, 248, ${alpha})`;
        ctx.lineWidth = 1.8;
        ctx.lineCap = 'round';
        ctx.stroke();

        p.x += vx;
        p.y += vy;
        p.age++;

        if (p.x < 0 || p.x > width || p.y < 0 || p.y > height || p.age >= p.maxAge) {
          p.x = Math.random() * width;
          p.y = Math.random() * height;
          p.age = 0;
          p.angle = baseAngle + (Math.random() - 0.5) * 0.4;
        }
      });

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (map) {
        map.off('resize', handleResize);
        map.off('move', handleResize);
      }
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (ctx) ctx.clearRect(0, 0, width, height);
    };
  }, [activeLayer, weatherData, theme]);

  // Smooth Zoom Functions
  const handleSmoothZoomIn = () => {
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.zoomIn(0.5, { animate: true });
  };

  const handleSmoothZoomOut = () => {
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.zoomOut(0.5, { animate: true });
  };

  // Quick Extent Smooth Navigations
  const goToWholeKarnataka = () => {
    if (onSelectLocation) {
      onSelectLocation({
        id: 'karnataka-all',
        name: 'Karnataka (Whole State)',
        district: 'All 31 Districts',
        state: 'Karnataka',
        country: 'India',
        latitude: 14.6500,
        longitude: 75.8500,
        elevation: 650,
      });
    }
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.flyTo([14.65, 75.85], 7.2, { duration: 1.2, easeLinearity: 0.25 });
  };

  const goToTumakuru = () => {
    const tumakuru = districtsRainData.find((d) => d.id === 'tumakuru-ka');
    if (tumakuru && onSelectLocation) {
      onSelectLocation({
        id: tumakuru.id,
        name: tumakuru.name,
        district: tumakuru.district,
        state: 'Karnataka',
        country: 'India',
        latitude: tumakuru.latitude,
        longitude: tumakuru.longitude,
      });
    }
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.flyTo([13.3409, 77.1006], 9.5, { duration: 1.2, easeLinearity: 0.25 });
  };

  const goToSouthIndia = () => {
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.flyTo([13.0, 77.5], 6.0, { duration: 1.4, easeLinearity: 0.25 });
  };

  const goToAllIndia = () => {
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.flyTo([21.5, 78.9], 4.8, { duration: 1.5, easeLinearity: 0.25 });
  };

  // Layer list configuration
  const layerOptions = [
    {
      id: 'satellite_gibs_terra',
      name: 'NASA Terra Optical Clouds',
      badge: 'Live Satellite',
      badgeColor: 'bg-cyan-50 text-[#007A8E] dark:bg-cyan-500/30 dark:text-cyan-200 border-cyan-200 dark:border-cyan-400/50',
      description: 'Real true-color optical cloud formations & terrain reflectance',
      icon: <Cloud className="w-5 h-5 text-[#00AFCB] dark:text-cyan-400" />,
    },
    {
      id: 'satellite_gibs_viirs',
      name: 'VIIRS High-Resolution Clouds',
      badge: '375m Nadir',
      badgeColor: 'bg-amber-50 text-amber-800 dark:bg-amber-500/30 dark:text-amber-200 border-amber-200 dark:border-amber-400/50',
      description: 'High-fidelity NASA VIIRS optical cloud texture',
      icon: <Sun className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
    },
    {
      id: 'cloud_cover',
      name: 'NASA Aqua Cloud Reflectance',
      badge: 'Cloudy Formed',
      badgeColor: 'bg-indigo-50 text-indigo-800 dark:bg-indigo-500/30 dark:text-indigo-200 border-indigo-200 dark:border-indigo-400/50',
      description: 'Atmospheric moisture & dense cloud systems over Karnataka',
      icon: <Cloud className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />,
    },
    {
      id: 'radar_rainviewer',
      name: 'Doppler Radar Precipitation',
      badge: 'Radar Rain',
      badgeColor: 'bg-blue-50 text-[#1E40AF] dark:bg-blue-500/30 dark:text-blue-200 border-blue-200 dark:border-blue-400/50',
      description: 'Real-time rain cells and dBZ storm reflectivity',
      icon: <CloudRain className="w-5 h-5 text-[#2563EB] dark:text-blue-400" />,
    },
    {
      id: 'wind_flow',
      name: 'Wind Stream Flow Particles',
      badge: 'Live Vector',
      badgeColor: 'bg-teal-50 text-teal-800 dark:bg-teal-500/30 dark:text-teal-200 border-teal-200 dark:border-teal-400/50',
      description: 'Dynamic surface monsoon wind trajectories across Karnataka',
      icon: <Wind className="w-5 h-5 text-teal-600 dark:text-teal-400" />,
    },
  ];

  return (
    <div
      className={`relative w-full rounded-2xl overflow-hidden glass-panel border border-[#D8E4ED] dark:border-cyan-500/25 shadow-xl transition-all ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : 'h-[520px] md:h-[600px] lg:h-[660px]'
      } ${className}`}
    >
      {/* Map DOM Container */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Wind Flow Canvas Overlay */}
      {activeLayer === 'wind_flow' && (
        <canvas
          ref={windCanvasRef}
          className="absolute inset-0 pointer-events-none z-10"
        />
      )}

      {/* Top Header Floating Overlay: Satellite Telemetry, Location & Quick Extents */}
      <div className="absolute top-3 inset-x-3 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* Left Telemetry Capsule */}
        <div className="pointer-events-auto flex items-center gap-2 bg-white/95 dark:bg-[#061022]/95 backdrop-blur-md px-3.5 py-2 rounded-xl border border-[#D8E4ED] dark:border-cyan-400/40 shadow-md text-[#172B3A] dark:text-slate-100">
          <div className="flex items-center gap-1.5 text-[#007A8E] dark:text-cyan-300 font-bold text-xs uppercase tracking-wider">
            <Radio className="w-3.5 h-3.5 text-[#00AFCB] dark:text-cyan-400 animate-pulse" />
            <span>Karnataka Satellite Core</span>
          </div>
          <span className="px-1.5 py-0.2 rounded-full bg-emerald-50 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-[10px] font-mono font-bold border border-emerald-300 dark:border-emerald-400/50 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
            LIVE MAP
          </span>
          <span className="text-[#D8E4ED] dark:text-slate-600">|</span>
          <div className="flex items-center gap-1 text-[11px] font-medium text-[#526779] dark:text-slate-200">
            <Clock className="w-3 h-3 text-[#00AFCB] dark:text-cyan-400" />
            <span>{lastRefreshedTime}</span>
          </div>
        </div>

        {/* Right Controls: Quick Extents, District Rain Pins Toggle, Layer Selector & Fullscreen */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Quick Extent Tabs */}
          <div className="hidden sm:flex items-center bg-white/95 dark:bg-[#061022]/95 backdrop-blur-md p-1 rounded-xl border border-[#D8E4ED] dark:border-cyan-400/30 shadow-md text-xs font-semibold text-[#526779] dark:text-slate-200">
            <button
              onClick={goToWholeKarnataka}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1 active:scale-95 cursor-pointer ${
                currentLocation.id === 'karnataka-all'
                  ? 'bg-[#E6F8FA] dark:bg-cyan-500/30 text-[#007A8E] dark:text-cyan-200 font-bold border border-[#00AFCB]/60 shadow-sm'
                  : 'hover:bg-[#F4F8FC] hover:text-[#172B3A] dark:hover:bg-cyan-500/20'
              }`}
              title="Show Whole State of Karnataka (Default)"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#00AFCB] dark:text-cyan-400" />
              <span>Karnataka (All 31)</span>
            </button>
            <button
              onClick={goToTumakuru}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1 active:scale-95 cursor-pointer ${
                currentLocation.id.includes('tumakuru')
                  ? 'bg-[#E6F8FA] dark:bg-cyan-500/30 text-[#007A8E] dark:text-cyan-200 font-bold border border-[#00AFCB]/60 shadow-sm'
                  : 'hover:bg-[#F4F8FC] hover:text-[#172B3A] dark:hover:bg-cyan-500/20'
              }`}
              title="Focus on Tumakuru District"
            >
              <MapPin className="w-3.5 h-3.5 text-[#00AFCB] dark:text-cyan-400" />
              <span>Tumakuru</span>
            </button>
            <button
              onClick={goToSouthIndia}
              className="px-2.5 py-1.5 rounded-lg hover:bg-[#F4F8FC] hover:text-[#172B3A] dark:hover:bg-cyan-500/20 transition cursor-pointer"
            >
              South India
            </button>
            <button
              onClick={goToAllIndia}
              className="px-2.5 py-1.5 rounded-lg hover:bg-[#F4F8FC] hover:text-[#172B3A] dark:hover:bg-cyan-500/20 transition cursor-pointer"
            >
              All India
            </button>
          </div>

          {/* District Rain Pins Toggle Button */}
          <button
            onClick={() => setShowDistrictRainPins(!showDistrictRainPins)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-bold backdrop-blur-md transition shadow-md cursor-pointer ${
              showDistrictRainPins
                ? 'bg-gradient-to-r from-[#00AFCB] to-[#2563EB] border-[#00AFCB] text-white shadow-cyan-900/30'
                : 'bg-white/95 dark:bg-[#061022]/95 border-[#D8E4ED] dark:border-slate-700 text-[#526779] dark:text-slate-300 hover:bg-[#F4F8FC] hover:text-[#172B3A] dark:hover:bg-slate-800'
            }`}
            title="Toggle All 31 Karnataka District Rain % Pins"
          >
            <Droplets className="w-4 h-4 text-cyan-200" />
            <span className="hidden md:inline">31 District Pins</span>
          </button>

          {/* Map Layer Selector Button */}
          <button
            onClick={() => setShowLayerMenu(true)}
            className="flex items-center gap-2 bg-gradient-to-r from-[#00AFCB] to-[#2563EB] hover:from-[#0096AD] hover:to-blue-600 border border-cyan-400/70 px-3.5 py-2 rounded-xl text-xs font-bold text-white shadow-md cursor-pointer transition active:scale-95"
            title="Open Map Layer Options"
          >
            <Layers className="w-4 h-4 text-white" />
            <span>Map Layers</span>
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="bg-white/95 dark:bg-[#061022]/95 backdrop-blur-md p-2.5 rounded-xl border border-[#D8E4ED] dark:border-cyan-400/40 text-[#526779] dark:text-cyan-300 hover:bg-[#F4F8FC] hover:text-[#172B3A] dark:hover:bg-cyan-950 transition shadow-md cursor-pointer"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Map'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Floating Center Badge: Current Focus Coordinates */}
      <div className="absolute top-16 left-3 z-20 pointer-events-none hidden md:flex items-center gap-2 bg-white/95 dark:bg-[#061022]/95 backdrop-blur-md px-3 py-1.5 rounded-xl border border-[#D8E4ED] dark:border-cyan-400/30 text-xs text-[#526779] dark:text-slate-200 shadow-md">
        <Compass className="w-3.5 h-3.5 text-[#00AFCB] dark:text-cyan-400" />
        <span>
          Selected: <strong className="text-[#172B3A] dark:text-white font-bold">{currentLocation.name}</strong> ({currentLocation.latitude.toFixed(2)}°N, {currentLocation.longitude.toFixed(2)}°E)
        </span>
        <span className="text-[#007A8E] dark:text-cyan-300 font-mono text-[11px] bg-[#E6F8FA] dark:bg-cyan-950/80 px-1.5 py-0.2 rounded border border-[#00AFCB]/40 dark:border-cyan-500/30 font-semibold">
          Tap pin to select
        </span>
      </div>

      {/* Floating Smooth Zoom In & Zoom Out Controls */}
      <div className="absolute right-3 top-24 z-20 flex flex-col gap-2">
        <button
          onClick={handleSmoothZoomIn}
          className="w-10 h-10 rounded-xl bg-white/95 dark:bg-[#071328]/95 hover:bg-[#F4F8FC] dark:hover:bg-cyan-950 border border-[#D8E4ED] dark:border-cyan-400/60 text-[#172B3A] dark:text-cyan-200 flex items-center justify-center shadow-md backdrop-blur-md transition active:scale-90 cursor-pointer text-lg font-bold"
          title="Smooth Zoom In"
        >
          <Plus className="w-5 h-5" />
        </button>
        <button
          onClick={handleSmoothZoomOut}
          className="w-10 h-10 rounded-xl bg-white/95 dark:bg-[#071328]/95 hover:bg-[#F4F8FC] dark:hover:bg-cyan-950 border border-[#D8E4ED] dark:border-cyan-400/60 text-[#172B3A] dark:text-cyan-200 flex items-center justify-center shadow-md backdrop-blur-md transition active:scale-90 cursor-pointer text-lg font-bold"
          title="Smooth Zoom Out"
        >
          <Minus className="w-5 h-5" />
        </button>
      </div>

      {/* Floating Legend Badge */}
      {showLegend && (
        <div className="absolute bottom-4 left-3 z-20 pointer-events-none hidden sm:block">
          <div className="pointer-events-auto bg-white/95 dark:bg-[#061022]/95 backdrop-blur-md p-3 rounded-xl border border-[#D8E4ED] dark:border-cyan-400/40 text-[11px] text-[#526779] dark:text-slate-200 shadow-xl max-w-[240px]">
            <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-[#D8E4ED] dark:border-cyan-500/20">
              <span className="font-bold text-[#007A8E] dark:text-cyan-300 uppercase tracking-wider text-[10px]">
                Karnataka District Rain Risk
              </span>
              <button
                onClick={() => setShowLegend(false)}
                className="text-[#687D8F] hover:text-[#172B3A] dark:hover:text-white cursor-pointer px-1 text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shadow-sm shadow-blue-500"></span>
                  High Rain Probability
                </span>
                <span className="font-mono text-[#1E40AF] dark:text-blue-300 font-bold">&ge; 60%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00AFCB] shadow-sm shadow-cyan-400"></span>
                  Moderate Chance
                </span>
                <span className="font-mono text-[#007A8E] dark:text-cyan-300 font-bold">30% – 59%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-400 dark:bg-slate-600"></span>
                  Low / Scattered
                </span>
                <span className="font-mono text-[#687D8F] dark:text-slate-400 font-medium">&lt; 30%</span>
              </div>
              <div className="text-[10px] text-[#007A8E] dark:text-cyan-300/80 pt-1.5 border-t border-[#D8E4ED] dark:border-slate-800 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-[#00AFCB] dark:text-cyan-400" />
                <span>Tap any pin to view & select district</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PROPERLY SCROLLABLE, HIGH-CONTRAST LAYER SELECTOR MODAL */}
      {showLayerMenu && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowLayerMenu(false);
          }}
          onWheel={(e) => e.stopPropagation()}
          onTouchMove={(e) => e.stopPropagation()}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            onWheel={(e) => e.stopPropagation()}
            onTouchMove={(e) => e.stopPropagation()}
            className="w-full max-w-md max-h-[88vh] flex flex-col rounded-2xl bg-white dark:bg-[#0a1835] border-2 border-[#00AFCB] dark:border-cyan-500/80 p-5 sm:p-6 shadow-2xl text-[#172B3A] dark:text-slate-100 animate-in zoom-in-95 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-3.5 border-b border-[#D8E4ED] dark:border-cyan-500/30 flex-shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#E6F8FA] dark:bg-cyan-500/20 text-[#007A8E] dark:text-cyan-400 border border-[#00AFCB]/40 dark:border-cyan-500/30">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-display text-base font-bold text-[#172B3A] dark:text-white tracking-tight">Select Weather Map Layer</h3>
                  <p className="text-[11px] text-[#007A8E] dark:text-cyan-300 font-normal">Choose real-time satellite, cloud & radar overlays</p>
                </div>
              </div>
              <button
                onClick={() => setShowLayerMenu(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[#526779] dark:text-slate-300 hover:text-[#172B3A] dark:hover:text-white flex items-center justify-center transition cursor-pointer"
                title="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Layer Options List - SMOOTH TOUCH & MOUSE SCROLLING */}
            <div
              className="mt-3.5 py-1 pr-1.5 space-y-2.5 overflow-y-auto max-h-[50vh] flex-1 overscroll-contain"
              style={{ WebkitOverflowScrolling: 'touch' }}
              onWheel={(e) => e.stopPropagation()}
              onTouchMove={(e) => e.stopPropagation()}
            >
              {layerOptions.map((opt) => {
                const isCurrent = activeLayer === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => {
                      setActiveLayer(opt.id as ActiveLayer);
                      setShowLayerMenu(false);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                      isCurrent
                        ? 'bg-[#E6F8FA] dark:bg-gradient-to-r dark:from-cyan-950 dark:to-[#0e2a56] border-[#00AFCB] dark:border-cyan-400 shadow-md ring-1 ring-[#00AFCB]'
                        : 'bg-white dark:bg-[#061226] border-[#D8E4ED] dark:border-slate-800 hover:border-[#00AFCB] hover:bg-[#F8FAFC] dark:hover:bg-[#0c1f3d]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-xl ${isCurrent ? 'bg-[#E6F8FA] dark:bg-cyan-500/25 border border-[#00AFCB]' : 'bg-[#F8FAFC] dark:bg-slate-900 border border-[#D8E4ED] dark:border-slate-800'}`}>
                        {opt.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-[#172B3A] dark:text-white">{opt.name}</span>
                          <span className={`px-2 py-0.2 rounded-full text-[10px] font-mono border font-semibold ${opt.badgeColor}`}>
                            {opt.badge}
                          </span>
                        </div>
                        <p className="text-xs text-[#526779] dark:text-slate-300 mt-0.5">{opt.description}</p>
                      </div>
                    </div>

                    <div className="ml-2 flex-shrink-0">
                      {isCurrent ? (
                        <div className="w-6 h-6 rounded-full bg-[#00AFCB] dark:bg-cyan-400 text-white dark:text-slate-950 flex items-center justify-center font-bold">
                          <Check className="w-4 h-4 stroke-[3]" />
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded-full border border-[#D8E4ED] dark:border-slate-700 bg-white dark:bg-slate-900" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Opacity Slider */}
            <div className="mt-3.5 pt-3.5 border-t border-[#D8E4ED] dark:border-slate-800 flex items-center justify-between flex-shrink-0">
              <div>
                <span className="text-xs font-bold text-[#172B3A] dark:text-slate-200 block">Layer Transparency</span>
                <span className="text-[11px] text-[#687D8F] dark:text-slate-400">Adjust cloud overlay contrast</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="0.3"
                  max="1.0"
                  step="0.05"
                  value={layerOpacity}
                  onChange={(e) => setLayerOpacity(parseFloat(e.target.value))}
                  className="w-28 sm:w-36 accent-[#00AFCB] dark:accent-cyan-400 h-2 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
                <span className="text-xs font-mono font-bold text-cyan-700 dark:text-cyan-300 w-9 text-right">
                  {Math.round(layerOpacity * 100)}%
                </span>
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={() => setShowLayerMenu(false)}
              className="mt-4 w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-cyan-900/30 transition active:scale-98 cursor-pointer flex-shrink-0"
            >
              Apply & Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
