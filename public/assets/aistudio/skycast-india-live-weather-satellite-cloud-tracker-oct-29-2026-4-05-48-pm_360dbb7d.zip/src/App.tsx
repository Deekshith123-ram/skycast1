/**
 * SkyCast India — Live Weather & Satellite Cloud Tracker
 * Default Showing: Whole State of Karnataka (All 31 Districts) & Satellite Telemetry
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { LocationData, WeatherData, WeatherAlert, DistrictRainData } from './types/weather';
import { DEFAULT_LOCATION } from './services/geocodingService';
import { fetchWeatherData, fetchAllKarnatakaDistrictsRain } from './services/weatherService';
import { evaluateWeatherAlerts } from './services/alertService';
import { Navbar } from './components/Navbar';
import { CurrentWeather } from './components/CurrentWeather';
import { SatelliteMap } from './components/SatelliteMap';
import { KarnatakaDistrictsRainGrid } from './components/KarnatakaDistrictsRainGrid';
import { INSATSatelliteViewer } from './components/INSATSatelliteViewer';
import { WeatherMetrics } from './components/WeatherMetrics';
import { HourlyForecast } from './components/HourlyForecast';
import { DailyForecast } from './components/DailyForecast';
import { WeatherCharts } from './components/WeatherCharts';
import { MonsoonTracker } from './components/MonsoonTracker';
import { WeatherAlerts } from './components/WeatherAlerts';
import { DataInfoFooter } from './components/DataInfoFooter';
import { OfflineIndicator } from './components/OfflineIndicator';
import { SettingsModal } from './components/SettingsModal';
import { MobileActionBar } from './components/MobileActionBar';
import { AndroidDownloadBanner } from './components/AndroidDownloadBanner';
import { LoadingScreen } from './components/LoadingScreen';
import { Loader2, AlertCircle, Radio } from 'lucide-react';

export default function App() {
  const [currentLocation, setCurrentLocation] = useState<LocationData>(DEFAULT_LOCATION);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [districtsRainData, setDistrictsRainData] = useState<DistrictRainData[]>([]);
  const [alerts, setAlerts] = useState<WeatherAlert[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isInitialLoading, setIsInitialLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const lastSyncTimestampRef = useRef<number>(Date.now());

  useEffect(() => {
    if (weatherData || error) {
      const timer = setTimeout(() => {
        setIsInitialLoading(false);
      }, 1100);
      return () => clearTimeout(timer);
    }
  }, [weatherData, error]);

  // Theme state: dark default, syncs with html class & localStorage
  const [theme, setThemeState] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('skycast_theme');
    return (saved === 'light' || saved === 'dark') ? saved : 'dark';
  });

  const setTheme = (t: 'dark' | 'light') => {
    setThemeState(t);
    localStorage.setItem('skycast_theme', t);
    if (t === 'light') {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
      document.documentElement.classList.add('dark');
    }
  };

  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
      document.documentElement.classList.add('dark');
    }
  }, [theme]);

  // Load weather data for the selected location (Default: Whole Karnataka)
  const loadWeather = useCallback(async (loc: LocationData) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchWeatherData(loc);
      setWeatherData(data);
      const generatedAlerts = evaluateWeatherAlerts(data);
      setAlerts(generatedAlerts);
      lastSyncTimestampRef.current = Date.now();
    } catch (err: any) {
      console.error('Failed to load weather data:', err);
      setError(err?.message || 'Unable to retrieve weather data.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Load all 31 Karnataka districts rain probability telemetry
  const loadDistrictsRain = useCallback(async () => {
    try {
      const data = await fetchAllKarnatakaDistrictsRain();
      setDistrictsRainData(data);
    } catch (err) {
      console.error('Error fetching district rain data:', err);
    }
  }, []);

  // Fetch initial Karnataka data on startup
  useEffect(() => {
    loadWeather(currentLocation);
    loadDistrictsRain();
  }, [currentLocation, loadWeather, loadDistrictsRain]);

  // Continuous LIVE telemetry sync: automatically refresh live readings and maps every 3 minutes
  useEffect(() => {
    const liveInterval = setInterval(() => {
      if (!document.hidden) {
        console.log('Auto-refreshing live weather and satellite telemetry...');
        loadWeather(currentLocation);
        loadDistrictsRain();
      }
    }, 180000); // 3 minutes

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        // If user was away for more than 2 minutes, immediately sync live values
        if (Date.now() - lastSyncTimestampRef.current > 120000) {
          loadWeather(currentLocation);
          loadDistrictsRain();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(liveInterval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [currentLocation, loadWeather, loadDistrictsRain]);

  // Handle location selection
  const handleSelectLocation = (loc: LocationData) => {
    setCurrentLocation(loc);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F4F8FC] text-[#172B3A] dark:bg-[#050b18] dark:text-slate-100 flex flex-col font-body font-normal transition-colors duration-200">
      {/* Full-screen immersive Loading / Splash Screen with Satellite & Earth Background */}
      <LoadingScreen isLoading={isInitialLoading} />

      {/* Offline Toast Indicator */}
      <OfflineIndicator />

      {/* A. Navigation Header */}
      <Navbar
        currentLocation={currentLocation}
        onSelectLocation={handleSelectLocation}
        onRefresh={() => {
          loadWeather(currentLocation);
          loadDistrictsRain();
        }}
        isLoading={isLoading}
        theme={theme}
        setTheme={setTheme}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-5 pb-28 sm:pb-8 md:py-8 space-y-6 md:space-y-8">
        {/* Android App Download Banner - Automatically hidden once downloaded/installed */}
        <AndroidDownloadBanner />

        {/* Error notification banner if any */}
        {error && (
          <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-500/40 text-xs text-rose-800 dark:text-rose-300 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400" />
              <span>{error}</span>
            </div>
            <button
              onClick={() => {
                loadWeather(currentLocation);
                loadDistrictsRain();
              }}
              className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold cursor-pointer"
            >
              Retry
            </button>
          </div>
        )}

        {/* B. Current Weather Section */}
        {weatherData ? (
          <CurrentWeather
            data={weatherData}
            onRefresh={() => loadWeather(currentLocation)}
            isLoading={isLoading}
          />
        ) : (
          <div className="h-44 rounded-2xl glass-panel animate-pulse flex items-center justify-center text-[#00AFCB] dark:text-cyan-400">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        )}

        {/* C. Karnataka Rain Monitor System (All 31 Districts Rain Probability Grid & Explorer) */}
        {districtsRainData.length > 0 && (
          <KarnatakaDistrictsRainGrid
            districts={districtsRainData}
            selectedLocation={currentLocation}
            onSelectDistrict={handleSelectLocation}
          />
        )}

        {/* D. Karnataka Satellite Cloud and Doppler Precipitation Tracker */}
        <section className="space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 px-1">
            <h2 className="font-display text-base sm:text-lg font-bold text-[#172B3A] dark:text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00AFCB] animate-ping"></span>
              Karnataka Satellite Cloud & Doppler Precipitation Tracker
            </h2>
            <span className="text-xs text-[#526779] dark:text-slate-400">
              Whole State Default View • All 31 District Rain Probability Overlays • Smooth Zoom
            </span>
          </div>

          <SatelliteMap
            currentLocation={currentLocation}
            weatherData={weatherData}
            onSelectLocation={handleSelectLocation}
            theme={theme}
          />
        </section>

        {/* E. Quick Weather Metrics */}
        {weatherData && (
          <WeatherMetrics
            current={weatherData.current}
            today={weatherData.daily[0]}
          />
        )}

        {/* F. Hourly Forecast (Scrollable) */}
        {weatherData && (
          <HourlyForecast hourly={weatherData.hourly} />
        )}

        {/* G. Seven-Day Synoptic Forecast */}
        {weatherData && (
          <DailyForecast daily={weatherData.daily} />
        )}

        {/* H. Detailed Weather Analysis Charts */}
        {weatherData && (
          <WeatherCharts hourly={weatherData.hourly} />
        )}

        {/* I. Dedicated Rainfall & Monsoon Monitoring */}
        {weatherData && (
          <MonsoonTracker weatherData={weatherData} />
        )}

        {/* J. IMD INSAT-3D/3DR Multi-Channel Imagery Observatory */}
        <INSATSatelliteViewer />

        {/* K. Weather Alerts & Meteorological Advisories */}
        <WeatherAlerts alerts={alerts} />

        {/* L. Data Information & Disclosures Footer */}
        <DataInfoFooter
          lastUpdated={weatherData?.lastUpdated ?? 'Syncing...'}
          isStale={weatherData?.isStale}
        />
      </main>

      {/* Phone-only bottom toolbar with Dark/Light, Refresh and Settings */}
      <MobileActionBar
        theme={theme}
        setTheme={setTheme}
        onRefresh={() => {
          loadWeather(currentLocation);
          loadDistrictsRain();
        }}
        isLoading={isLoading}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        theme={theme}
        setTheme={setTheme}
      />
    </div>
  );
}
