import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
      proxy: {
        '/api/open-meteo': {
          target: 'https://api.open-meteo.com',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api\/open-meteo/, ''),
        },
        '/api/geocoding-open-meteo': {
          target: 'https://geocoding-api.open-meteo.com',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api\/geocoding-open-meteo/, ''),
        },
        '/api/rainviewer': {
          target: 'https://api.rainviewer.com',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api\/rainviewer/, ''),
        },
      },
    },
  };
});
