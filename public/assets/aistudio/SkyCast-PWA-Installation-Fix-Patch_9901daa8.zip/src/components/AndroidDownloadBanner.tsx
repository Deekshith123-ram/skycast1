import React, { useState } from 'react';
import { Download, X, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const AndroidDownloadBanner: React.FC = () => {
  const { isInstallable, isInstalled, isAndroid, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(
    () => localStorage.getItem('skycast_banner_dismissed') === 'true'
  );

  if (!isAndroid || isInstalled || dismissed) return null;

  const handleInstall = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) return;
    }

    // Browser install prompt is not always exposed; give the user the manual Chrome route.
    window.alert('Open this SkyCast website in Chrome, tap the ⋮ menu, then choose “Install app” or “Add to Home screen”.');
  };

  const handleDismiss = () => {
    setDismissed(true);
    localStorage.setItem('skycast_banner_dismissed', 'true');
  };

  return (
    <div className="w-full rounded-2xl bg-gradient-to-r from-emerald-950/80 via-[#062638] to-slate-900 border border-emerald-500/40 p-3.5 sm:p-4 text-white shadow-xl relative overflow-hidden flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in slide-in-from-top-2">
      <div className="flex items-center gap-3 z-10">
        <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
          <Smartphone className="w-6 h-6" />
        </div>
        <div>
          <h4 className="font-display text-sm font-bold text-white tracking-tight">Install SkyCast on your phone</h4>
          <p className="text-xs text-slate-300 mt-0.5">Add SkyCast to your Home screen for an app-like experience. Updates arrive from the live website.</p>
        </div>
      </div>
      <div className="flex items-center gap-2 self-end sm:self-center z-10">
        <button
          onClick={handleInstall}
          className="water-droplet-btn flex items-center gap-1.5 px-4 py-2 rounded-full text-emerald-300 font-bold text-xs shadow-md cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Install</span>
        </button>
        <button
          onClick={handleDismiss}
          className="water-droplet-btn p-2 rounded-full text-slate-400 hover:text-white cursor-pointer"
          title="Dismiss banner"
          aria-label="Dismiss install banner"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
