import React, { useState } from 'react';
import { Download, X, Smartphone, Monitor, Share } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isAndroid, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) return null;

  const handleInstall = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) setShowGuide(false);
      else setShowGuide(true);
      return;
    }
    setShowGuide(true);
  };

  return (
    <>
      <button
        onClick={handleInstall}
        className="water-droplet-btn flex-shrink-0 whitespace-nowrap flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-bold text-emerald-700 dark:text-emerald-300 shadow-md cursor-pointer"
        title="Install SkyCast on this device"
      >
        <Download className="w-4 h-4" />
        <span>Install App</span>
      </button>

      {showGuide && (
        <div
          onClick={(event) => {
            if (event.target === event.currentTarget) setShowGuide(false);
          }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4"
        >
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-[#09152b] border border-[#D8E4ED] dark:border-emerald-500/40 p-5 shadow-2xl text-[#172B3A] dark:text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-[#D8E4ED] dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="font-display text-base font-bold">Install SkyCast</h3>
              </div>
              <button onClick={() => setShowGuide(false)} aria-label="Close install guide">
                <X className="w-4 h-4" />
              </button>
            </div>

            {isAndroid ? (
              <div className="mt-4 space-y-3 text-sm text-[#526779] dark:text-slate-300">
                <p>To install SkyCast from Chrome:</p>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Open this website in the latest Google Chrome.</li>
                  <li>Tap the Chrome menu (⋮).</li>
                  <li>Choose <strong>Install app</strong> or <strong>Add to Home screen</strong>, then confirm.</li>
                </ol>
                <p className="text-xs">If the install option is missing, reload the website over HTTPS and check again. The browser decides when the install option is available.</p>
              </div>
            ) : isIOS ? (
              <div className="mt-4 space-y-2 text-sm text-[#526779] dark:text-slate-300">
                <p>On iPhone or iPad, open SkyCast in Safari, tap <Share className="inline w-4 h-4" /> <strong>Share</strong>, then choose <strong>Add to Home Screen</strong>.</p>
              </div>
            ) : (
              <div className="mt-4 space-y-2 text-sm text-[#526779] dark:text-slate-300">
                <p>In Chrome or Edge on your computer:</p>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Open the SkyCast website over HTTPS.</li>
                  <li>Select the install icon in the address bar, or open the browser menu.</li>
                  <li>Choose <strong>Install SkyCast</strong> and confirm.</li>
                </ol>
                <p className="flex items-center gap-2 text-xs"><Monitor className="w-4 h-4" /> Works with supported Chromium-based desktop browsers.</p>
              </div>
            )}

            <button
              onClick={() => setShowGuide(false)}
              className="mt-5 w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
