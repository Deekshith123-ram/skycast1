# SkyCast PWA installation and update patch

This ZIP contains proposed replacement files for the current `Deekshith123-ram/skycast1` repository.

## What this patch changes
- Configures the already-declared `vite-plugin-pwa` in `vite.config.ts`.
- Generates/registers a service worker during the Vite production build.
- Enables `registerType: 'autoUpdate'`, so an installed PWA checks for new website builds and activates updated app assets automatically.
- Keeps the existing `public/manifest.json` and existing icon assets.
- Stops treating an APK download or a user tapping “I've Installed” as proof that the app is installed.
- Replaces the misleading APK-download UI with browser-native PWA installation and manual browser instructions.
- Keeps live weather/API requests out of the precache. The app shell/static assets are precached; live weather data continues to be fetched by the app.

## Files to replace
- `vite.config.ts`
- `src/hooks/usePWAInstall.ts`
- `src/components/PWAInstallButton.tsx`
- `src/components/AndroidDownloadBanner.tsx`

## Apply and deploy
1. Make a backup or create a new Git branch.
2. Replace only the four files above with the matching files in this ZIP.
3. Run `npm install` (the project already declares `vite-plugin-pwa`).
4. Run `npm run build` and resolve any build errors before deployment.
5. Commit/push to the GitHub branch connected to Vercel.
6. Deploy the production build over HTTPS.
7. Open the deployed website in Chrome on Android and Chrome/Edge on Windows, then install it using the browser's Install app option.

## Important behavior
- The installed PWA is the live website in an app window; it is not a separately packaged native APK.
- When a new Vercel deployment updates the website, the service worker checks for the new build and updates the installed PWA. A reload/reopen may be needed to display the new version depending on browser lifecycle.
- Browser install prompts are controlled by the browser and are not guaranteed to appear on every visit. The manual install instructions cover that case.
- This patch does not change weather APIs, backend routes, data logic, maps, or other app features.
- No GitHub files were changed and nothing was pushed by preparing this ZIP.
- Build and device verification have not yet been run; apply this patch on a branch and test before merging to production.
